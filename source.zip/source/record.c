#ifndef RECORD_C
#define RECORD_C

/* This is a struct to represent a single record.
 * You are NOT allowed to modify this file.
 */
struct record {
    char name[500];
    int idNumber;
};

typedef struct record Record;

#endif